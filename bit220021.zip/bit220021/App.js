import React from 'react';
import { View, Text, ScrollView, StyleSheet, Image } from 'react-native';

const NotificationItem = ({ icon, title, description, time }) => {

  const getIconSource = (iconName) => {
    if (iconName === 'checkmark-circle') {
      return require('./assets/checkmark.png');
    } else if (iconName === 'people') {
      return require('./assets/people.png');
    }

    return require('./assets/default.png'); 
  };

  // Lấy đường dẫn ảnh dựa trên tên icon
  const iconSource = getIconSource(icon);

  return (
    <View style={styles.notificationItem}>
      <Image source={iconSource} style={styles.icon} />
      <View style={styles.textContainer}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.description}>{description}</Text>
        <Text style={styles.time}>{time}</Text>
      </View>
    </View>
  );
};

const App = () => {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Thông báo</Text>
      <NotificationItem
        icon="checkmark-circle"
        title="Bước 1 Xác định nhu cầu khách hàng"
        description="Vũ Văn Hoàng sắp đến hạn lúc 01/08/2020 9:00"
        time="20/08/2020, 06:00"
      />
      <NotificationItem
        icon="people"
        title="Bạn có khách hàng mới!"
        description="Chúc mừng bạn, bạn có khách hàng mới. Hãy mau chóng liên lạc ngay."
        time="20/08/2020, 06:00"
      />
      <NotificationItem
        icon="people"
        title="Khách hàng được chia sẻ bị trùng"
        description="Rất tiếc, khách hàng được chia sẻ đã tồn tại trên hệ thống. Vui lòng chia sẻ khách hàng."
        time="20/08/2020, 06:00"
      />
      <NotificationItem
        icon="people"
        title="Khách hàng được thêm bị trùng"
        description="Rất tiếc, khách hàng được thêm đã tồn tại trên hệ thống. Vui lòng thêm khách hàng."
        time="20/08/2020, 06:00"
      />
      <NotificationItem
        icon="checkmark-circle"
        title="Công việc sắp đến hạn trong hôm nay"
        description="Bạn có 17 công việc sắp đến hạn trong hôm nay."
        time="20/08/2020, 06:00"
      />
      <NotificationItem
        icon="checkmark-circle"
        title="Công việc đã quá hạn"
        description="Bạn có 17 công việc bị quá hạn. Hãy kiểm tra và lên kế hoạch hoàn thành công việc."
        time="20/08/2020, 06:00"
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 16,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  notificationItem: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 2 },
  },
  icon: {
    width: 24,
    height: 24,
    marginRight: 12,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    color: '#555',
    marginBottom: 4,
  },
  time: {
    fontSize: 12,
    color: '#999',
  },
});

export default App;

